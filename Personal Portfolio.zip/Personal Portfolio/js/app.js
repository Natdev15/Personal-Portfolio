// start of Slick Slider "Reviews Section"

$(document).ready(function(){
    $('.slider').slick({
        arrows: false,
        dots: true,
        appendDots: '.slider-dots',
        dotsClass: 'dots'
    });
})

// end of Slick Slider "Reviews Section"





// start of Mobile-nav Trigger Effect 

$(function() {
    $(".mobile-nav-trigger").click(function(){
        $(".mobile-nav").removeClass("open");
      });
})

// end of Mobile-nav Trigger Effect 




// start of mobile-nav 

// const hamberger = document.getElementsByClassName('hamberger'); 
// or 
const hamberger = document.querySelector('.hamberger');
const times = document.querySelector('.times');
const mobileNav = document.querySelector('.mobile-nav');

hamberger.addEventListener('click', function() {
    mobileNav.classList.add('open');
});
times.addEventListener('click', function() {
    mobileNav.classList.remove('open');
});

// end of mobile-nav 


